
import os
import random

from flask import Flask, render_template, url_for, redirect, jsonify, Response, abort, session, request, send_file
from werkzeug.utils import secure_filename
import shutil
import time
import csv
import tarfile
import serial_device
import quality_test_ml
import sweetness_from_color_ml
import webbrowser

#Install Build Tools: https://aka.ms/vs/17/release/vs_BuildTools.exe

USERNAMES = ['gnits', 'admin', 'user', 'test']
PASSWORDS = ['gnits@12345', 'Admin@12345', 'User@12345', 'Test@12345']


SENSOR_LOG_CSV= './static/sensor_data.csv'
COLOR_TO_SWEETNESS_CSV = "./static/sweetness_from_color.csv"

app = Flask(__name__)

UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'face_data/')
AUDIO_FOLDER = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'audio_data/')
CAPTURE_FOLDER = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'captured_picture/')

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
outputFrame = None
number = random.randint(1000000, 9999999)


def check_csv_file():
    try:
        f1 = open(SENSOR_LOG_CSV, 'r')
        f1.close()
    except:
        f1 = open(SENSOR_LOG_CSV, 'w')
        f1.write("Size,Weight,Apple_Juice_R,Apple_Juice_G,Apple_Juice_B,Apple_Juice_Lux,Apple_Juice_CT,Apple_Nitrogen,Apple_Phosphorus,Apple_Potassium,Apple_Juice_PH,Sweetness,label\n")
        f1.close()
    
    try:
        f1 = open(COLOR_TO_SWEETNESS_CSV, 'r')
        f1.close()
    except:
        f1 = open(COLOR_TO_SWEETNESS_CSV, 'w')
        f1.write("R,G,B,LUX,CT,Sweetness\n")
        f1.close()

check_csv_file()


print("\nTrain Color to Sweetnes Model")
try:
    mse = sweetness_from_color_ml.do_train()
    print("Color to Sweetness Model Trained with Mean Squared Error: ", mse)
except Exception as e:
    print("Failed to Train Color to Sweetness Model. Reason: ", e)
    print("Raw Values of R, G, B will be used to train Model")
    time.sleep(2)

print("\n\nTrain Fruit Quality Model")
model_accuracy = quality_test_ml.do_train()
print("Fruit Quality Model Trained with Accuracy: ", model_accuracy)
print()

serial_device.read_data_from_hub()

def make_tarfile(output_filename, source_dir):
    print("Making Tarfile")
    with tarfile.open(output_filename, "w:gz") as tar:
        tar.add(source_dir, arcname=os.path.basename(source_dir))


def calculate_sweetness(juice_r, juice_g, juice_b, juice_lux, juice_color):
    try:
        sweetness = sweetness_from_color_ml.predict([juice_r, juice_g, juice_b, juice_lux, juice_color])

        return sweetness
    except Exception as e:
        return 0


def html_return(msg, redirect_to = "/", delay = 5):
    return f"""
                <html>    
                    <head>      
                        <title>Fruit Quality</title>      
                        <meta http-equiv="refresh" content="{delay};URL='{redirect_to}'" />    
                    </head>    
                    <body> 
                        <div style="text-align: center; margin-top: 20%;">
                            <br>
                            <h2> {msg}</h2>
                            <p>This page will refresh automatically.</p> 
                        </div>
                    </body>  
                </html>   
                
                """



@app.route('/', methods=['get', 'post'])
def login_page():
    global model_accuracy


    if request.method == 'POST':
        username, password = request.form['username'], request.form['password']
        if username in USERNAMES:
            if password == PASSWORDS[USERNAMES.index(username)]:
                session['user'] = username
                return render_template('index.html', user=(session['user']), model_accuracy=model_accuracy)
            
        return render_template('login-page.html')
    elif 'user' in session.keys():
        return render_template('index.html', user=(session['user']), model_accuracy=model_accuracy)
    else:
        return render_template('login-page.html')


@app.route('/logout/')
def logout():
    session.clear()
    return redirect(url_for('login_page'))


@app.route('/all_data/')
def all_data():
    if 'user' in session.keys():
        try:
            file = csv.reader(open(SENSOR_LOG_CSV, 'r'))
            data_list = []
            for row in file:
                print("Row:", row)
                data_list.append(row)
        except:
            data_list = []
        
        return render_template('all_data.html', user=(session['user']), data_list=data_list[1:], wait_time = int(len(data_list)/50))
    else:
        return redirect(url_for('login_page'))


@app.route('/test_fruit_quality/', methods=['get', 'post'])
def test_fruit_quality():
    global model_accuracy

    if 'user' in session.keys():

        if request.method == 'GET':
            op = serial_device.read_data_from_hub()
            if op is not None and type(op) == list and op[1]>0:
                print("Proper Data Received")
                return render_template('test_fruit_quality.html', user=(session['user']), data_list=op)
            else:
                print("Improper Data Received:", op)
                return render_template('test_fruit_quality.html', user=(session['user']), data_list=[])
            

        if request.method == "POST":
            input_data = []

            data = request.form.to_dict()
            print("Test Form Data:", data)

            calculated_sweetness = calculate_sweetness(data['juice_r'], data['juice_g'], data['juice_b'], data['juice_lux'], data['juice_color'])

            input_data = [float(data['size']),float(data['weight']),float(data['juice_r']),float(data['juice_g']),float(data['juice_b']),float(data['juice_lux']),float(data['juice_color']),float(data['nitrogen']),float(data['phosphorous']),float(data['pottasium']),float(data['juice_ph']),calculated_sweetness]
            
            prediction = quality_test_ml.predict(input_data)
            return render_template('result.html', user=(session['user']), prediction=prediction, model_accuracy=model_accuracy)
            return html_return(f"Prediction: {prediction}", redirect_to="/test_fruit_quality/", delay=10)
    
    else:
        return redirect(url_for('login_page'))
    

@app.route('/collect_new_data/', methods=['get', 'post'])
def collect_new_data():
    if 'user' in session.keys():
        if request.method == 'GET':
            op = serial_device.read_data_from_hub()
            if op is not None and type(op) == list and op[1]>0:
                print("Proper Data Received")
                return render_template('collect_new_data.html', user=(session['user']), data_list=op)
            else:
                print("Improper Data Received:", op)
                return render_template('collect_new_data.html', user=(session['user']), data_list=[])
            
        if request.method == "POST":

            data = request.form.to_dict()
            print("Form Data:", data)

            calculated_sweetness = calculate_sweetness(data['juice_r'], data['juice_g'], data['juice_b'], data['juice_lux'], data['juice_color'])

            f1 = open(SENSOR_LOG_CSV, 'a')
            f1.write(f"{data['size']},{data['weight']},{data['juice_r']},{data['juice_g']},{data['juice_b']},{data['juice_lux']},{data['juice_color']},{data['nitrogen']},{data['phosphorous']},{data['pottasium']},{data['juice_ph']},{calculated_sweetness},{data['label']}\n")
            f1.close()

            return html_return(f"Data Collected Successfully:<br>{str(data)}", redirect_to="/collect_new_data/", delay=5)
    else:
        return redirect(url_for('login_page'))

@app.route('/retrain_model/')
def retrain_model():
    if 'user' in session.keys():
        acc = quality_test_ml.do_train()
        return html_return(f"Model Retrained Successfully with accuracy of {acc}%", redirect_to="/manage/", delay=5)
    else:
        return redirect(url_for('login_page'))  


@app.route('/manage/')
def manage():
    if 'user' in session.keys():
        return render_template('manage.html', user=(session['user']))
    else:
        return redirect(url_for('login_page'))
    

@app.route('/delete_all_data/', methods=['get', 'post'])
def delete_all_data():
    if 'user' in session.keys():
        try:
            os.remove(SENSOR_LOG_CSV)

            check_csv_file()
            
            print("Deleted All Data")
            return html_return("Successfully Deleted Sensor Data")
        except Exception as e:
            print("Failed to Delete Sensor Data. Reason: "+str(e))
            return html_return("Failed to Delete Sensor Data. Reason: "+str(e))
    else:
        return redirect(url_for('login_page'))

@app.errorhandler(404)
def nice(_):
    return render_template('error_404.html')


app.secret_key = 'q12q3q4e5g5htrh@werwer15454'

if __name__ == '__main__':
    port = 5000
    webbrowser.open(f'http://127.0.0.1:{port}/')
    app.run(host='0.0.0.0', port= port, debug=False)#80)
# global outputFrame ## Warning: Unused global
