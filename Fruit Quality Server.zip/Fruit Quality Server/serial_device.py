
import time

import serial
import serial.tools.list_ports



apple_size = 0
apple_weight = 0
apple_nitrogen = 0
apple_phosphorus = 0
apple_potassium = 0

apple_juice_R = 0
apple_juice_G = 0
apple_juice_B = 0
apple_juice_Lux = 0
apple_juice_CT = 0
apple_juice_PH = 0


def find_arduino_uno():
    # List all available ports
    ports = serial.tools.list_ports.comports()
    
    # Scan through the ports to find the one connected to Arduino Uno
    for port in ports:
        # The description contains 'Arduino' when an Arduino is connected
        if 'arduino' in str(port.description).lower() or 'arduino' in str(port.name).lower() or 'arduino' in str(port.manufacturer).lower():
            return port.device
        # else:
        #     print("#####")
        #     print(port.description)
        #     print(port.name)
        #     print(port.manufacturer)
        #     print(port.hwid)
        #     print(port.product)
        #     print(port.usb_description())
        #     print(port.usb_info())
        #     print(port.device)
        
    return None

arduino_port = None
ser = None

def form_connection():
    global arduino_port, ser

    arduino_port = find_arduino_uno()

    if arduino_port:
        print(f"Arduino Uno found on port: {arduino_port}")
        ser = None

        # Close the port if it's already open
        try:
            temp_ser = serial.Serial(arduino_port)
            temp_ser.close()
        except:
            pass

        try:
            ser = serial.Serial( port=arduino_port, baudrate=115200, timeout=1,
                                bytesize=serial.EIGHTBITS, parity=serial.PARITY_NONE,
                                stopbits=serial.STOPBITS_ONE, xonxoff=False,        # Disable software flow control
                                rtscts=False,         # Disable hardware flow control
                                dsrdtr=False          # Disable hardware flow control
                                )
            print(f"\nSuccessfully connected to {arduino_port}")
            # Toggle DTR to reset Arduino

            ser.dtr = False
            time.sleep(0.1)
            ser.dtr = True
            # Wait for connection to stabilize
            time.sleep(2)

            ser.reset_input_buffer()
            ser.reset_output_buffer()
            time.sleep(10)  # Give the serial port time to initialize

            print("Connection established")
                    
        except serial.SerialException as e:
            print(f"Error opening serial port: {e}")
            ser = None
        
    else:
        print("Arduino Uno not found.")
        ser = None
        arduino_port = None


def read_data_from_hub():
    global apple_size,apple_weight,apple_nitrogen,apple_phosphorus,apple_potassium,apple_juice_R,apple_juice_G,apple_juice_B,apple_juice_Lux,apple_juice_CT,apple_juice_PH, arduino_port, ser

    if ser is None:
        form_connection()     
        
    if ser is not None:
        if ser.is_open: # Connection Formed
            # print("Reading Data")
            ser.write(b'READ')  # Send a byte to request data from Arduino
            time.sleep(1.5)  # Small delay to prevent CPU overload
            if ser.in_waiting > 0:
                try:
                    # Read line from serial port
                    # line = ser.readline().decode('utf-8').strip()
                    line = ser.read_until(b'####\n').decode('utf-8').strip()
                    line = line.replace("\r", "")
                    line = line.replace(" ", "")
                    line = line.lower()
                    
                    # print(datetime.now())
                    # print(f"Received: {line}")

                    if("****" in line and "####" in line):
                        if(line.index("****") < line.index("####")):
                            line = line[line.index("****")+4:line.index("####")].strip()
                            # print("Data Ready to be Parsed")

                            apple_size = 0
                            apple_weight = 0
                            apple_nitrogen = 0
                            apple_phosphorus = 0
                            apple_potassium = 0

                            apple_juice_R = 0
                            apple_juice_G = 0
                            apple_juice_B = 0
                            apple_juice_Lux = 0
                            apple_juice_CT = 0
                            apple_juice_PH = 0
                            
                            data_list = line.split("\n")

                            print(data_list)

                            for data in data_list:
                                if("size" in data):
                                    try:
                                        apple_size = float(data.split(":")[1].replace("cm",""))
                                    except:
                                        apple_size = -99
                                elif("weight" in data):
                                    try:
                                        apple_weight = float(data.split(":")[1].replace("g",""))
                                    except:
                                        apple_weight = -99
                                elif("r:" in data):
                                    try:
                                        apple_juice_R = float(data.split(":")[1])
                                    except:
                                        apple_juice_R = -99
                                elif("g:" in data):
                                    try:
                                        apple_juice_G = float(data.split(":")[1])
                                    except:
                                        apple_juice_G = -99
                                elif("b:" in data):
                                    try:
                                        apple_juice_B = float(data.split(":")[1])
                                    except:
                                        apple_juice_B = -99
                                elif("lux:" in data):
                                    try:
                                        apple_juice_Lux = float(data.split(":")[1])
                                    except:
                                        apple_juice_Lux = -99
                                elif("ct:" in data):
                                    try:
                                        apple_juice_CT = float(data.split(":")[1].replace("k",""))
                                    except:
                                        apple_juice_CT = -99
                                elif("nitro" in data):
                                    try:
                                        apple_nitrogen = float(data.split(":")[1].replace("mg/kg",""))
                                    except:
                                        apple_nitrogen = -99
                                elif("phosp" in data):
                                    try:
                                        apple_phosphorus = float(data.split(":")[1].replace("mg/kg",""))
                                    except:
                                        apple_phosphorus = -99
                                elif("potas" in data):
                                    try:
                                        apple_potassium = float(data.split(":")[1].replace("mg/kg",""))
                                    except:
                                        apple_potassium = -99
                                elif("phval" in data):
                                    try:
                                        apple_juice_PH = float(data.split(":")[1])
                                    except:
                                        apple_juice_PH = -99
                                else:
                                    print("Unknown Data: ",data)

                            print("Apple Size: ",apple_size)
                            print("Apple Weight: ",apple_weight)
                            print("Apple Juice R: ",apple_juice_R)
                            print("Apple Juice G: ",apple_juice_G)
                            print("Apple Juice B: ",apple_juice_B)
                            print("Apple Juice Lux: ",apple_juice_Lux)
                            print("Apple Juice CT: ",apple_juice_CT)
                            print("Apple Nitrogen: ",apple_nitrogen)
                            print("Apple Phosphorus: ",apple_phosphorus)
                            print("Apple Potassium: ",apple_potassium)
                            print("Apple Juice PH: ",apple_juice_PH)

                            return [apple_size, apple_weight, apple_juice_R, apple_juice_G, apple_juice_B, apple_juice_Lux, apple_juice_CT, apple_nitrogen, apple_phosphorus, apple_potassium, apple_juice_PH]
                            
                    else:
                        print("Data not ready to be parsed")
                        time.sleep(0.1)

                    time.sleep(10)
       
                except UnicodeDecodeError:
                    print("Error decoding data, retry")
                    time.sleep(0.1)  # Small delay to prevent CPU overload

                except Exception as e:
                    print("Unable to Parse Data: ", e)
            else:
                print("No Data available")
                time.sleep(0.001)
        else:
            print("Serial is not open")
            time.sleep(0.001)

    else:
        print("Connection not established")
        time.sleep(1)
        form_connection()
    


if __name__ == "__main__":
    read_data_from_hub()

    time.sleep(5)

    read_data_from_hub()