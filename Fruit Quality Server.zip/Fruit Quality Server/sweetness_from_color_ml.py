import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

COLOR_TO_SWEETNESS_CSV = "./static/sweetness_from_color.csv"
model = None

def load_data(file_path):
    data = pd.read_csv(file_path)
    return data

def split_data(data):
    X = data[['R', 'G', 'B', 'LUX', 'CT']]
    y = data['Sweetness']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    return X_train, X_test, y_train, y_test

def train_model(X_train, y_train):
    global model
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    return model

def test_model(X_test, y_test):
    global model
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    return mse

def exclude_columns(data, columns_to_exclude):
    return data.drop(columns=columns_to_exclude, axis=1)

def predict(input_data):
    global model
    print("Input Data", input_data)
    print("Length:", len(input_data))
    op = model.predict([input_data])
    print("Prediction:", op)
    return op[0]

def do_train():
    global model, COLOR_TO_SWEETNESS_CSV
    columns_to_exclude = []
    data = load_data(COLOR_TO_SWEETNESS_CSV)
    if len(columns_to_exclude) > 0:
        data = exclude_columns(data, columns_to_exclude)
    X_train, X_test, y_train, y_test = split_data(data)
    model = train_model(X_train, y_train)
    mse = test_model(X_test, y_test)
    print(f"Model Mean Squared Error: {mse}")
    return mse

if __name__ == "__main__":
    do_train()
    # Example prediction
    input_data = [150, 200, 300, 400, 500]  # Example input data
    prediction = predict(input_data)
    print(f"Prediction: {prediction}")