import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, AdaBoostClassifier
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
# Size,Weight,Apple_Juice_R,Apple_Juice_G,Apple_Juice_B,Apple_Juice_Lux,Apple_Juice_CT,Apple_Nitrogen,Apple_Phosphorus,Apple_Potassium,Apple_Juice_PH,Sweetness,Label

SENSOR_LOG_CSV= './static/sensor_data.csv'
model = None

def load_data(file_path):
    data = pd.read_csv(file_path)
    return data

def split_data(data):
    X = data.drop('label', axis=1)
    y = data['label']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    return X_train, X_test, y_train, y_test

def train_model(X_train, y_train):
    global model
    #model = MLPClassifier(hidden_layer_sizes=(100,), max_iter=300, random_state=42)
    #model = RandomForestClassifier(n_estimators=100, random_state=42)
    model = GradientBoostingClassifier(random_state=42)
    #model = XGBClassifier(random_state=42)
    #model = LGBMClassifier(random_state=42)
    #model = CatBoostClassifier(random_state=42, verbose=0)
    #model = AdaBoostClassifier(random_state=42)
    #model = SVC(random_state=42)  
    #model = KNeighborsClassifier()
    model.fit(X_train, y_train)
    return model

def test_model(X_test, y_test):
    global model
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    return int(accuracy*100)

def exclude_columns(data, columns_to_exclude):
    return data.drop(columns=columns_to_exclude, axis=1)

def predict(input_data):
    global model
    print("Input Data",input_data)
    print("Length:", len(input_data))
    op = model.predict([input_data])
    print("Prediction:", op)

    return op[0]



def do_train():
    global model, SENSOR_LOG_CSV

    
    # columns_to_exclude = ['Sweetness', ]
    columns_to_exclude = []

    data = load_data(SENSOR_LOG_CSV)
    
    if len(columns_to_exclude) > 0:
        data = exclude_columns(data, columns_to_exclude)
    X_train, X_test, y_train, y_test = split_data(data)
    model = train_model(X_train, y_train)
    accuracy = test_model(X_test, y_test)
    print(f"Model Accuracy: {accuracy}")

    return accuracy


if __name__ == "__main__":
    

    do_train()
   
    # Example prediction
    input_data = [150, 200, 300, 400, 500, 600, 700, 800, 900, 7.0, 0, 8.0]  # Example input data
    prediction = predict(input_data)
    print(f"Prediction: {prediction}")